Distribution domain name: https://dace88zy8nsab.cloudfront.net
Static website hosting URL: http://my-754591336505-bucket.s3-website-us-east-1.amazonaws.com
S3 Object URL: https://my-754591336505-bucket.s3.amazonaws.com/index.html